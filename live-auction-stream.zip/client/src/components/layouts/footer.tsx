import React, { Component } from "react";


export class Footer extends Component{

  render() {
    return <div className="text-center">
    
     All rights reserved JohnMogi &copy;
    
     </div>;
  }
}