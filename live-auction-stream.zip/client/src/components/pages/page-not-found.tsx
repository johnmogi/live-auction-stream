import React, { Component } from "react";
export class PageNotFound extends Component {
  render() {
    return <> 
    404
    
     </>;
  }
}