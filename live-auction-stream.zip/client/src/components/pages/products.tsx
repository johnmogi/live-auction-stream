import React, { Component } from "react";
import { ProductModel } from "../model/Product-model";
import { BidModel } from "../model/Bid-model";



import Modal from "react-bootstrap/Modal";
import Button from "react-bootstrap/Button";

const BASE_API_URL = `http://localhost:3001/api/products`;



interface ProductState{
  products: ProductModel[],
  bid: BidModel
}
// const [show, setShow] = useState(false);

//   const handleClose = () => setShow(false);
//   const handleShow = () => setShow(true);



export class Products extends Component <any, ProductState> {

  public constructor(props: any) {
    super(props);
    this.state = {
      products: [],
      bid: new BidModel()
    }
  }
  public componentDidMount(): void {
    fetch(BASE_API_URL)
      .then((response) => response.json())
      .then((products) => this.setState({ products }))
      .catch((err) => alert(err.message));
  }

  
  render() {
    return <> 
    <h2>Here are our {this.state.products.length} products</h2>

    <Modal >
        <Modal.Header closeButton>
          <Modal.Title>Add User</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          
          component goes here
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" >
            Close
          </Button>
          <Button variant="primary" >
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
 
<div className="row">

    {this.state.products.map((p) => (
      <div className="card col-4" key={p.productID}>
            <Button>name: {p.productName}
              </Button> 
            <br />
            {p.price}
          </div>
        ))}
   
        </div>
     </>;
  }
}