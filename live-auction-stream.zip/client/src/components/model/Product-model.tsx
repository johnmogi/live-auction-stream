export class ProductModel{
    public constructor(
public productID? :number,
public productName? :string,
public category? :string,
public price? :number,
public SKU? :string,
public salePrice? :number,
public stock? :number
)
{}}