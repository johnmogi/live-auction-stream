export class BidModel{
    public constructor(
public bidID? :number,
public productID? :number,
public bidOffer? :number,
public bidStart? :string,
public bidEnd? :string
    )
{}}